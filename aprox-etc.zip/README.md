#AProx system configuration for Project Newcastle

This repository contains configuration for the way AProx will start and run. It contains information about where files are located on the system, which add-ons are enabled, etc. It is often used in conjuction with another Git repository, which is used to store repository definitions, content templates, and the like.
