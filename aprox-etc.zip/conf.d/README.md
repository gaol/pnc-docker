#Add-On Configurations for AProx

You can place individual *.conf files here and have them picked up in the AProx configuration, since the /etc/main.conf file uses:

    Include conf.d/*.conf
