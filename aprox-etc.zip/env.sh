
MAIN_CLASS=org.commonjava.aprox.boot.vertx.VertxBooter
