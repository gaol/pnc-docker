# AProx Configuration Data for Project Newcastle

This repository contains auto-proxy rules and other configuration files related to managing repositories for products and individual builds.